const tracks = [
  {id:'neon-horizon',title:'Neon Horizon',artist:'SafeWave Originals',genre:'Electronic',mood:'Energetic',energy:'High',bpm:128,use:'Gaming intro',duration:'0:12',file:'audio/neon-horizon.wav',color:'c1'},
  {id:'golden-hour-drive',title:'Golden Hour Drive',artist:'SafeWave Originals',genre:'Indie',mood:'Uplifting',energy:'Medium',bpm:104,use:'Travel vlog',duration:'0:12',file:'audio/golden-hour-drive.wav',color:'c2'},
  {id:'quiet-circuit',title:'Quiet Circuit',artist:'SafeWave Originals',genre:'Lo-fi',mood:'Focused',energy:'Low',bpm:76,use:'Study video',duration:'0:12',file:'audio/quiet-circuit.wav',color:'c3'},
  {id:'rise-beyond',title:'Rise Beyond',artist:'SafeWave Originals',genre:'Cinematic',mood:'Epic',energy:'High',bpm:112,use:'Trailer build',duration:'0:12',file:'audio/rise-beyond.wav',color:'c4'},
  {id:'afterglow',title:'Afterglow',artist:'SafeWave Originals',genre:'Pop',mood:'Hopeful',energy:'Medium',bpm:116,use:'Lifestyle reel',duration:'0:12',file:'audio/afterglow.wav',color:'c5'},
  {id:'open-mic',title:'Open Mic',artist:'SafeWave Originals',genre:'Ambient',mood:'Calm',energy:'Low',bpm:68,use:'Podcast bed',duration:'0:12',file:'audio/open-mic.wav',color:'c6'},
  {id:'midnight-notes',title:'Midnight Notes',artist:'SafeWave Originals',genre:'Jazz',mood:'Reflective',energy:'Low',bpm:84,use:'Late-night story',duration:'0:12',file:'audio/midnight-notes.wav',color:'c7'},
  {id:'level-up',title:'Level Up',artist:'SafeWave Originals',genre:'Hip-Hop',mood:'Confident',energy:'High',bpm:96,use:'Sports edit',duration:'0:12',file:'audio/level-up.wav',color:'c8'}
];

const state = {query:'',genre:'all',mood:'all',energy:'all',favoritesOnly:false,current:null,favorites:new Set(JSON.parse(localStorage.getItem('safewave_favorites') || '[]'))};
const audio = document.getElementById('audio');
const trackList = document.getElementById('trackList');
const player = document.getElementById('player');
const $ = id => document.getElementById(id);

function escapeHtml(value){return value.replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function populateFilters(){
  [...new Set(tracks.map(t=>t.genre))].sort().forEach(v=>$('genreFilter').insertAdjacentHTML('beforeend',`<option>${v}</option>`));
  [...new Set(tracks.map(t=>t.mood))].sort().forEach(v=>$('moodFilter').insertAdjacentHTML('beforeend',`<option>${v}</option>`));
}
function filteredTracks(){
  const q=state.query.toLowerCase().trim();
  return tracks.filter(t=>{
    const haystack=[t.title,t.artist,t.genre,t.mood,t.energy,t.use].join(' ').toLowerCase();
    return (!q||haystack.includes(q))&&(state.genre==='all'||t.genre===state.genre)&&(state.mood==='all'||t.mood===state.mood)&&(state.energy==='all'||t.energy===state.energy)&&(!state.favoritesOnly||state.favorites.has(t.id));
  });
}
function render(){
  const list=filteredTracks();
  $('resultsText').textContent=`Showing ${list.length} of ${tracks.length} track${tracks.length===1?'':'s'}`;
  $('favoriteCount').textContent=state.favorites.size;
  $('favoritesToggle').classList.toggle('active',state.favoritesOnly);
  $('favoritesToggle').setAttribute('aria-pressed',String(state.favoritesOnly));
  trackList.innerHTML=list.map(t=>`<article class="track-row ${state.current===t.id?'active':''}" data-id="${t.id}">
    <button class="track-art ${t.color}" data-action="play" aria-label="Play ${escapeHtml(t.title)}">${state.current===t.id&&!audio.paused?'❚❚':'▶'}</button>
    <div class="track-main"><strong>${escapeHtml(t.title)}</strong><span>${escapeHtml(t.artist)} · ${escapeHtml(t.use)}</span></div>
    <div class="track-tags"><span>${t.genre}</span><span>${t.mood}</span></div>
    <div class="track-meta"><span>${t.energy} energy</span><span>${t.bpm} BPM · ${t.duration}</span></div>
    <div class="track-actions"><button class="icon-button ${state.favorites.has(t.id)?'active':''}" data-action="favorite" aria-label="Favorite ${escapeHtml(t.title)}">${state.favorites.has(t.id)?'♥':'♡'}</button><a class="download-button" href="${t.file}" download="${t.id}.wav">Download</a></div>
  </article>`).join('');
  $('emptyState').hidden=list.length>0;
}
function playTrack(id){
  const track=tracks.find(t=>t.id===id); if(!track)return;
  if(state.current===id){audio.paused?audio.play():audio.pause();return;}
  state.current=id;audio.src=track.file;audio.play();
  player.hidden=false;$('playerTitle').textContent=track.title;$('playerArtist').textContent=track.artist;$('playerDownload').href=track.file;$('playerDownload').download=`${track.id}.wav`;$('playerDuration').textContent=track.duration;updatePlayerFavorite();render();
}
function toggleFavorite(id){
  state.favorites.has(id)?state.favorites.delete(id):state.favorites.add(id);
  localStorage.setItem('safewave_favorites',JSON.stringify([...state.favorites]));updatePlayerFavorite();render();
}
function updatePlayerFavorite(){const active=state.current&&state.favorites.has(state.current);$('playerFavorite').textContent=active?'♥':'♡';$('playerFavorite').classList.toggle('active',active);}
function clearFilters(){state.query='';state.genre='all';state.mood='all';state.energy='all';state.favoritesOnly=false;$('librarySearch').value='';$('genreFilter').value='all';$('moodFilter').value='all';$('energyFilter').value='all';render();}
function formatTime(seconds){if(!Number.isFinite(seconds))return '0:00';return `${Math.floor(seconds/60)}:${String(Math.floor(seconds%60)).padStart(2,'0')}`;}

trackList.addEventListener('click',e=>{const row=e.target.closest('.track-row');if(!row)return;const action=e.target.closest('[data-action]')?.dataset.action;if(action==='play')playTrack(row.dataset.id);if(action==='favorite')toggleFavorite(row.dataset.id);});
$('librarySearch').addEventListener('input',e=>{state.query=e.target.value;render();});
$('genreFilter').addEventListener('change',e=>{state.genre=e.target.value;render();});
$('moodFilter').addEventListener('change',e=>{state.mood=e.target.value;render();});
$('energyFilter').addEventListener('change',e=>{state.energy=e.target.value;render();});
$('favoritesToggle').addEventListener('click',()=>{state.favoritesOnly=!state.favoritesOnly;render();});
$('clearFilters').addEventListener('click',clearFilters);$('emptyClear').addEventListener('click',clearFilters);
$('heroSearch').addEventListener('submit',e=>{e.preventDefault();state.query=$('heroSearchInput').value;$('librarySearch').value=state.query;render();$('library').scrollIntoView({behavior:'smooth'});});
document.querySelectorAll('.chips button').forEach(btn=>btn.addEventListener('click',()=>{state.query=btn.dataset.query;$('librarySearch').value=state.query;render();$('library').scrollIntoView({behavior:'smooth'});}));
$('playerPlay').addEventListener('click',()=>audio.paused?audio.play():audio.pause());
$('playerFavorite').addEventListener('click',()=>state.current&&toggleFavorite(state.current));
$('playerProgress').addEventListener('input',e=>{if(audio.duration)audio.currentTime=(e.target.value/100)*audio.duration;});
audio.addEventListener('play',()=>{$('playerPlay').textContent='❚❚';render();});audio.addEventListener('pause',()=>{$('playerPlay').textContent='▶';render();});
audio.addEventListener('timeupdate',()=>{$('playerCurrent').textContent=formatTime(audio.currentTime);$('playerProgress').value=audio.duration?(audio.currentTime/audio.duration)*100:0;});
audio.addEventListener('loadedmetadata',()=>{$('playerDuration').textContent=formatTime(audio.duration);});
audio.addEventListener('ended',()=>{$('playerPlay').textContent='▶';$('playerProgress').value=0;render();});

document.getElementById('year').textContent=new Date().getFullYear();
document.getElementById('waitlistForm').addEventListener('submit',function(event){event.preventDefault();const email=$('email').value.trim();if(!email)return;localStorage.setItem('safewave_waitlist_email',email);const message=$('formMessage');message.textContent="You're on the founding waitlist — welcome to SafeWave!";message.classList.add('success');this.reset();});
populateFilters();render();
